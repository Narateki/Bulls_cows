package com.example.bc;


import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class BluetoothGame extends Activity {
	BluetoothGame mAct;
	Button buttonOk1;
	EditText editText1;
	EditText editText2;
	EditText editText3;
	Button button1;
	Button button2;
	Button button3;
	Button button4;
	Button button5;
	Button button6;
	Button button7;
	Button button8;
	Button button9;
	Button button0;
	Button buttonOk2;
	Button buttonC;
	bull_cow gm = new bull_cow();
	static int x;
	public boolean Correct() {
		if (editText1.getText().toString().length()==0) 
			return true; 
		if (!gm.CorrectNum(Integer.parseInt(editText1.getText().toString()))) 
		{
			editText1.setBackgroundResource(R.color.red); 
			return false;
		}
		else return true;
	}
	
	
	
	// Debugging
    private static final String TAG = "BluetoothChat";
    private static final boolean D = true;

    // Message types sent from the BluetoothChatService Handler
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;

    // Key names received from the BluetoothChatService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";

    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE = 1;
    private static final int REQUEST_ENABLE_BT = 2;

    // Name of the connected device
    private String mConnectedDeviceName = null;
    // String buffer for outgoing messages
    private StringBuffer mOutStringBuffer;
    // Local Bluetooth adapter
    private BluetoothAdapter mBluetoothAdapter = null;
    // Member object for the chat services
    private BluetoothChatService mChatService = null;

	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bluetooth_game);
		gm.czc = 0;
		// Для использования API ActionBar убедимся, что мы используем платформу Honeycomb и выше
	    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
	        // Отобразим кнопку Up в меню.
	        getActionBar().setDisplayHomeAsUpEnabled(true);
	    }
	    mAct=this;
	    this.setTitle(R.string.guess_number_comp);
	    // Получаем сообщение из объекта intent
	    Intent intent = getIntent();	    
	    
		editText1 = (EditText) findViewById(R.id.editText1); 
		editText2 = (EditText) findViewById(R.id.editText2);
		editText3 = (EditText) findViewById(R.id.editText3);
		buttonOk2 = (Button) findViewById(R.id.buttonOk2);
		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		button3 = (Button) findViewById(R.id.button3);
		button4 = (Button) findViewById(R.id.button4);
		button5 = (Button) findViewById(R.id.button5);
		button6 = (Button) findViewById(R.id.button6);
		button7 = (Button) findViewById(R.id.button7);
		button8 = (Button) findViewById(R.id.button8);
		button9 = (Button) findViewById(R.id.button9);
		button0 = (Button) findViewById(R.id.button0);
		buttonC = (Button) findViewById(R.id.buttonC);
		OnClickListener oclBtnButtonOk2 = new OnClickListener() {  
			int b=1;
			@Override
			public void onClick(View v) {
				if (editText1.getText().toString().length()==0) 
					return; 
					if (!gm.CorrectNum(Integer.parseInt(editText1.getText().toString()))) 
					{
						editText1.setBackgroundResource(R.color.red);
					}
					else {
						editText1.setBackgroundResource(R.color.green);
						if (b==1) {
							gm.n=Integer.parseInt(editText1.getText().toString());
							editText1.setText("");
							editText1.setHint(R.string.EditText1Hint);
							mAct.setTitle(getBaseContext().getString(R.string.your_number_comp) + gm.n);
							b=0;
							// Check that we're actually connected before trying anything
					        if (mChatService.getState() != BluetoothChatService.STATE_CONNECTED) {
					            Toast.makeText(mAct, R.string.not_connected, Toast.LENGTH_SHORT).show();
					            return;
					        }
					        else {
					        	if (gm.n>0) mAct.sendMessage(String.valueOf(gm.n));
					        }
						}
						else {
							int a = Integer.parseInt(editText1.getText().toString());
							gm.HCGame(a);
							editText2.setText(gm.sh+"\n"+editText2.getText().toString());
							mAct.sendMessage(gm.sh);
							if (gm.hp==1) {
								editText2.setText(getBaseContext().getString(R.string.your_win)+"\n"+editText2.getText().toString());
								mAct.sendMessage(getBaseContext().getString(R.string.enemy_win));
							}
							
							editText1.setText("");
						} //else
					} //else
			} //onClick
		}; //OnClickListener oclBtnButtonOk2
		OnClickListener oclBtnButton1 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "1");
			} //onClick
		}; //OnClickListener oclBtnButton1
		OnClickListener oclBtnButton2 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "2");
			} //onClick
		}; //OnClickListener oclBtnButton2
		OnClickListener oclBtnButton3 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "3");
			} //onClick
		}; //OnClickListener oclBtnButton3
		OnClickListener oclBtnButton4 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "4");
			} //onClick
		}; //OnClickListener oclBtnButton4
		OnClickListener oclBtnButton5 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "5");
			} //onClick
		}; //OnClickListener oclBtnButton5
		OnClickListener oclBtnButton6 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "6");
			} //onClick
		}; //OnClickListener oclBtnButton6
		OnClickListener oclBtnButton7 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "7");
			} //onClick
		}; //OnClickListener oclBtnButton7
		OnClickListener oclBtnButton8 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "8");
			} //onClick
		}; //OnClickListener oclBtnButton8
		OnClickListener oclBtnButton9 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "9");
			} //onClick
		}; //OnClickListener oclBtnButton9
		OnClickListener oclBtnButton0 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "0");
			} //onClick
		}; //OnClickListener oclBtnButton0
		OnClickListener oclBtnButtonC = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText("");
				editText1.setBackgroundResource(R.color.green);
			} //onClick
		}; //OnClickListener oclBtnButtonC
		buttonOk2.setOnClickListener(oclBtnButtonOk2);
		button1.setOnClickListener(oclBtnButton1);
		button2.setOnClickListener(oclBtnButton2);
		button3.setOnClickListener(oclBtnButton3);
		button4.setOnClickListener(oclBtnButton4);
		button5.setOnClickListener(oclBtnButton5);
		button6.setOnClickListener(oclBtnButton6);
		button7.setOnClickListener(oclBtnButton7);
		button8.setOnClickListener(oclBtnButton8);
		button9.setOnClickListener(oclBtnButton9);
		button0.setOnClickListener(oclBtnButton0);
		buttonC.setOnClickListener(oclBtnButtonC);
		 // Get local Bluetooth adapter
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        // If the adapter is null, then Bluetooth is not supported
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
		
	} //onCreate
	
	@Override
    public void onStart() {
        super.onStart();

        // If BT is not on, request that it be enabled.
        // setupChat() will then be called during onActivityResult
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
        // Otherwise, setup the chat session
        } else {
            if (mChatService == null) setupChat();
        }
    } //onStart
	
	 @Override
	    public synchronized void onResume() {
	        super.onResume();
	        if(D) Log.e(TAG, "+ ON RESUME +");

	        // Performing this check in onResume() covers the case in which BT was
	        // not enabled during onStart(), so we were paused to enable it...
	        // onResume() will be called when ACTION_REQUEST_ENABLE activity returns.
	        if (mChatService != null) {
	            // Only if the state is STATE_NONE, do we know that we haven't started already
	            if (mChatService.getState() == BluetoothChatService.STATE_NONE) {
	              // Start the Bluetooth chat services
	              mChatService.start();
	            }
	        }
	    }

	    private void setupChat() {
	        // Initialize the BluetoothChatService to perform bluetooth connections
	        mChatService = new BluetoothChatService(this, mHandler);
	        // Initialize the buffer for outgoing messages
	        mOutStringBuffer = new StringBuffer("");
	    }

	    @Override
	    public synchronized void onPause() {
	        super.onPause();
	    }

	    @Override
	    public void onStop() {
	        super.onStop();
	    }

	    @Override
	    public void onDestroy() {
	        super.onDestroy();
	        // Stop the Bluetooth chat services
	        if (mChatService != null) mChatService.stop();
	    }

	    private void ensureDiscoverable() {
	        if(D) Log.d(TAG, "ensure discoverable");
	        if (mBluetoothAdapter.getScanMode() !=
	            BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
	            Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
	            discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
	            startActivity(discoverableIntent);
	        }
	    }

	    /**
	     * Sends a message.
	     * @param message  A string of text to send.
	     */
	    public void sendMessage(String message) {
	        // Check that we're actually connected before trying anything
	        if (mChatService.getState() != BluetoothChatService.STATE_CONNECTED) {
	            Toast.makeText(this, R.string.not_connected, Toast.LENGTH_SHORT).show();
	            return;
	        }

	        // Check that there's actually something to send
	        if (message.length() > 0) {
	            // Get the message bytes and tell the BluetoothChatService to write
	            byte[] send = message.getBytes();
	            mChatService.write(send);
	        }
	    }

	    // The Handler that gets information back from the BluetoothChatService
	    private final Handler mHandler = new Handler() {
	        @Override
	        public void handleMessage(Message msg) {
	            switch (msg.what) {
	            case MESSAGE_STATE_CHANGE:
	                if(D) Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
	                switch (msg.arg1) {
	                case BluetoothChatService.STATE_CONNECTED:
	                    mAct.setTitle(getBaseContext().getString(R.string.title_connected_to) + mConnectedDeviceName);
	                    break;
	                case BluetoothChatService.STATE_CONNECTING:
	                    mAct.setTitle(R.string.title_connecting);
	                    if (gm.n>0) mAct.sendMessage(String.valueOf(gm.n)); 
	                    break;
	                case BluetoothChatService.STATE_LISTEN:
	                case BluetoothChatService.STATE_NONE:
	            	    mAct.setTitle(R.string.title_not_connected);
	                    break;
	                }
	                break;
	            case MESSAGE_WRITE:
	                byte[] writeBuf = (byte[]) msg.obj;
	                // construct a string from the buffer
	                String writeMessage = new String(writeBuf);
	                break;
	            case MESSAGE_READ:
	                byte[] readBuf = (byte[]) msg.obj;
	                // construct a string from the valid bytes in the buffer
	                String readMessage = new String(readBuf, 0, msg.arg1);
	                if(mAct.gm.czc == 0) {
	                	mAct.gm.czc= Integer.parseInt(readMessage);
	                	Toast.makeText(mAct, R.string.Number_recieved, Toast.LENGTH_SHORT).show();
	                }
	                else {
	                	editText3.setText(readMessage +"\n"+editText3.getText().toString());
	                }
	                break;
	            case MESSAGE_DEVICE_NAME:
	                // save the connected device's name
	                mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
	                Toast.makeText(getApplicationContext(), "Connected to "
	                               + mConnectedDeviceName, Toast.LENGTH_SHORT).show();
	                break;
	            case MESSAGE_TOAST:
	                Toast.makeText(getApplicationContext(), msg.getData().getString(TOAST),
	                               Toast.LENGTH_SHORT).show();
	                break;
	            }
	        }
	    };

	    public void onActivityResult(int requestCode, int resultCode, Intent data) {
	        if(D) Log.d(TAG, "onActivityResult " + resultCode);
	        switch (requestCode) {
	        case REQUEST_CONNECT_DEVICE:
	            // When DeviceListActivity returns with a device to connect
	            if (resultCode == Activity.RESULT_OK) {
	                // Get the device MAC address
	                String address = data.getExtras()
	                                     .getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
	                // Get the BLuetoothDevice object
	                BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
	                // Attempt to connect to the device
	                mChatService.connect(device);
	            }
	            break;
	        case REQUEST_ENABLE_BT:
	            // When the request to enable Bluetooth returns
	            if (resultCode == Activity.RESULT_OK) {
	                // Bluetooth is now enabled, so set up a chat session
	                setupChat();
	            } else {
	                // User did not enable Bluetooth or an error occured
	                Log.d(TAG, "BT not enabled");
	                Toast.makeText(this, R.string.bt_not_enabled_leaving, Toast.LENGTH_SHORT).show();
	                finish();
	            }
	        }
	    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.bluetooth_game, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case R.id.scan:
            // Launch the DeviceListActivity to see devices and do scan
            Intent serverIntent = new Intent(mAct, DeviceListActivity.class);
            startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
            return true;
        case R.id.discoverable:
            // Ensure this device is discoverable by others
            ensureDiscoverable();
            return true;
        }
        return false;
    }
}
