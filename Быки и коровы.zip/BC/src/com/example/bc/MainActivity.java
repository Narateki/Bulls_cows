package com.example.bc;




import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
	
public void sendHumCompGame(View view) {
		
		// Создаем объект Intent для вызова новой Activity
		Intent intent = new Intent(this, HumCompGame.class);		
		 // запуск activity
	    startActivity(intent);
	}
public void sendHumHumGame(View view) {
	
	// Создаем объект Intent для вызова новой Activity
	Intent intent = new Intent(this, HumHumGame.class);		
	 // запуск activity
    startActivity(intent);
}
public void sendBluetoothGame(View view) {
	
	// Создаем объект Intent для вызова новой Activity
	Intent intent = new Intent(this, BluetoothGame.class);		
	 // запуск activity
    startActivity(intent);
}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
	}

}
