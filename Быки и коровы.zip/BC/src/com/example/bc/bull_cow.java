package com.example.bc;

import java.util.Random;

public class bull_cow {

	
	int n1,n2,n3,n4,allNum1; //первое число для ВС
	int nn1,nn2,nn3,nn4,allNum2; //второе число для ВС
	int hum1=0,hum2=0,winner=0;
	int n=4078,i,j=0,bc,r,f=0,bb,cc,czc=0,hp=0,cp=0;
	int[] c = new int[4536];
	String sh,sc;
	
	
	
	public bull_cow() {
		Random rand = new Random();
		//заполняем массив корректными числами
		for (i=1023; i<=9876; i++) {
			if (CorrectNum(i)) {
				c[j]=i;
				j++;
			}
		}
		j--;
        czc = c[rand.nextInt(j)];
	}
	
	public boolean CorrectNum(int intNum) {
		int c1,c2,c3,c4;
		c1 = intNum/1000;
		c2 = intNum/100%10;
		c3 = intNum%100/10;
		c4 = intNum%10;
		if (intNum >=1023 && intNum <= 9876 && c1!=0 && c1!=c2 && c1!=c3 && c1!=c4 && c2!=c3 && c2!=c4 && c3!=c4 )
		{
			return true;
		}
		else return false;
	}
	
	public boolean CorrectNum(int num1, int num2){  
		n1 = num1/1000;
		n2 = num1/100%10;
		n3 = num1%100/10;
		n4 = num1%10;
		nn1 = num2/1000;
		nn2 = num2/100%10;
		nn3 = num2%100/10;
		nn4 = num2%10;
		if (num1 >=1023 && num1 <= 9876 && n1!=0 && n1!=n2 && n1!=n3 && n1!=n4 && n2!=n3 && n2!=n4 && n3!=n4 && num2 >=1023 && num2 <= 9876 && nn1!=0 && nn1!=nn2 && nn1!=nn3 && nn1!=nn4 && nn2!=nn3 && nn2!=nn4 && nn3!=nn4 )
		{
			return true;
		}
		else return false;
	}
	
	public int Get_BC(int num1, int num2) {
		if (!CorrectNum(num1, num2)) return 100;
		int cow=0, bull=0;
		//ищем коров
		if (n1 == nn2 || n1 == nn3 || n1 == nn4) cow++;
		if (n2 == nn1 || n2 == nn3 || n2 == nn4) cow++;
		if (n3 == nn1 || n3 == nn2 || n3 == nn4) cow++;
		if (n4 == nn1 || n4 == nn2 || n4 == nn3) cow++;
		//ищем быков
		if (n1 == nn1) bull++;
		if (n2 == nn2) bull++;
		if (n3 == nn3) bull++;
		if (n4 == nn4) bull++;
		return bull*10+cow;
	}
	
	public void HCGame(int a) 
	{
		int bulls=0, cows=0;
			// отгадывает человек
			bc=Get_BC(a, czc);
			if (bc>9) 
			{
			bulls = bc/10;
			cows = bc%10;
			}
			else 
			{
				bulls=0;
				cows=bc;
			}
			sh=a + "  B: " + bulls + "  C:" + cows;
			if ( bulls == 4 ) hp=1;
			// отгадывает машина
			// выбираем число
			if (cp==0) {
			r = 0;
			while(c[r] == 0)
			{
				r++;
				if ( r > j ) r = 0;
			}
			a = c[r];
			// проверяем кол-во быков и коров
			bc=Get_BC(a, n);
			if (bc>9) 
			{
				bulls = bc/10;
				cows = bc%10;
			}
			else 
			{
				bulls=0;
				cows=bc;
			} 
			sc=a + "  B: " + bulls + "  C:" + cows;
			// проверяем отгадано ли число
			if ( bulls == 4 ) cp=1;
			// если не отгадано убираем все неподходящие числа
			f++;
			for (i = 0; i<=j; i++) 
			{
				if ( c[i] == 0 ) continue;
				bc=Get_BC(a, c[i]);
				if (bc>9) 
				{
					bb = bc/10;
					cc = bc%10;
				}
				else 
				{
					bb=0;
					cc=bc;
				}
				if ( bb !=bulls || cc !=cows) 
				{
					c[i]=0;
				}
			} //for
			} //if cp=0
			else {
				cp=2;
			}
	} //HCGame
	public void HH_Game1(int a) {
		int bulls=0, cows=0;
		// отгадывает человек
		bc=Get_BC(a, hum2);
		if (bc>9) 
		{
		bulls = bc/10;
		cows = bc%10;
		}
		else 
		{
			bulls=0;
			cows=bc;
		}
		if (bulls==4) winner=1;
		sh=a + "  B: " + bulls + "  C: " + cows;
		
	}
	public void HH_Game2(int a) {
		int bulls=0, cows=0;
		// отгадывает человек
		bc=Get_BC(a, hum1);
		if (bc>9) 
		{
		bulls = bc/10;
		cows = bc%10;
		}
		else 
		{
			bulls=0;
			cows=bc;
		}
		if (bulls==4) winner=1;
		sh=a + "  B: " + bulls + " C: " + cows;
	}
	


}

