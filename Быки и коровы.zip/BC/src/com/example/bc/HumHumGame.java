package com.example.bc;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

@SuppressLint("ResourceAsColor")
public class HumHumGame extends Activity {
	Activity mAct;
	Button buttonOk1;
	EditText editText1;
	EditText editText2;
	EditText editText3;
	Button button1;
	Button button2;
	Button button3;
	Button button4;
	Button button5;
	Button button6;
	Button button7;
	Button button8;
	Button button9;
	Button button0;
	Button buttonOk2;
	Button buttonC;
	bull_cow gm = new bull_cow();
	static int x;
	public boolean Correct() {
		if (editText1.getText().toString().length()==0) 
			return true; 
		if (!gm.CorrectNum(Integer.parseInt(editText1.getText().toString()))) 
		{
			editText1.setBackgroundResource(R.color.red); 
			return false;
		}
		else return true;
	}
	public void Winner1() {
		if (gm.winner==1) {
			editText2.setText(getBaseContext().getString(R.string.your_win) + "\n"+editText2.getText().toString());
			editText3.setText(getBaseContext().getString(R.string.enemy_win) + "\n"+editText3.getText().toString());
		}
	}
	public void Winner2() {
		if (gm.winner==1) {
			editText2.setText(getBaseContext().getString(R.string.enemy_win)+"\n"+editText2.getText().toString());
			editText3.setText(getBaseContext().getString(R.string.your_win)+"\n"+editText3.getText().toString());
		}
	}
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_hum_hum_game);
	    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
	        getActionBar().setDisplayHomeAsUpEnabled(true);
	    }
	    mAct=this;
	    this.setTitle(R.string.guess_number_1);
	    Intent intent = getIntent();
	    editText1 = (EditText) findViewById(R.id.editText1);
		editText2 = (EditText) findViewById(R.id.editText2);
		editText3 = (EditText) findViewById(R.id.editText3);
		buttonOk2 = (Button) findViewById(R.id.buttonOk2);
		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		button3 = (Button) findViewById(R.id.button3);
		button4 = (Button) findViewById(R.id.button4);
		button5 = (Button) findViewById(R.id.button5);
		button6 = (Button) findViewById(R.id.button6);
		button7 = (Button) findViewById(R.id.button7);
		button8 = (Button) findViewById(R.id.button8);
		button9 = (Button) findViewById(R.id.button9);
		button0 = (Button) findViewById(R.id.button0);
		buttonC = (Button) findViewById(R.id.buttonC);
		OnClickListener oclBtnButtonOk2 = new OnClickListener() {   //button1
			@Override
			public void onClick(View v) {
				editText1.setBackgroundResource(R.color.green);
				if (gm.hum1==0) {
					if (Correct()) {
						gm.hum1=Integer.parseInt(editText1.getText().toString());
						editText1.setText("");
						mAct.setTitle(R.string.guess_number_2);
					}
				}
				else if (gm.hum2==0) {
					if (Correct()) { 
						gm.hum2=Integer.parseInt(editText1.getText().toString());
						editText1.setText("");
						mAct.setTitle(R.string.turn_1);
						x=1;
						editText1.setHint(R.string.EditText1Hint);
					}
				}
				else if (x==1) { 
						if (Correct()) {
							int a = Integer.parseInt(editText1.getText().toString());
							gm.HH_Game1(a);
							editText2.setText(gm.sh+"\n"+editText2.getText().toString());
							Winner1();
							mAct.setTitle(R.string.turn_2);
							x=2;
							editText1.setText("");
							editText1.setHint(R.string.EditText1Hint);
						}
					}
				else if (x==2) { 
						if (Correct()) {
							int a = Integer.parseInt(editText1.getText().toString());
							gm.HH_Game2(a);
							editText3.setText(gm.sh+"\n"+editText3.getText().toString());
							Winner2();
							mAct.setTitle(R.string.turn_1);
							x=1;
							editText1.setText("");
							editText1.setHint(R.string.EditText1Hint);
						}
					} 
			} //onClick
		}; //OnClickListener oclBtnButtonOk2
		OnClickListener oclBtnButton1 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "1");
			} //onClick
		}; //OnClickListener oclBtnButton1
		OnClickListener oclBtnButton2 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "2");
			} //onClick
		}; //OnClickListener oclBtnButton2
		OnClickListener oclBtnButton3 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "3");
			} //onClick
		}; //OnClickListener oclBtnButton3
		OnClickListener oclBtnButton4 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "4");
			} //onClick
		}; //OnClickListener oclBtnButton4
		OnClickListener oclBtnButton5 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "5");
			} //onClick
		}; //OnClickListener oclBtnButton5
		OnClickListener oclBtnButton6 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "6");
			} //onClick
		}; //OnClickListener oclBtnButton6
		OnClickListener oclBtnButton7 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "7");
			} //onClick
		}; //OnClickListener oclBtnButton7
		OnClickListener oclBtnButton8 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "8");
			} //onClick
		}; //OnClickListener oclBtnButton8
		OnClickListener oclBtnButton9 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "9");
			} //onClick
		}; //OnClickListener oclBtnButton9
		OnClickListener oclBtnButton0 = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText(editText1.getText().toString() + "0");
			} //onClick
		}; //OnClickListener oclBtnButton0
		OnClickListener oclBtnButtonC = new OnClickListener() {   
			@Override
			public void onClick(View v) {
				editText1.setText("");
				editText1.setBackgroundResource(R.color.green);
			} //onClick
		}; //OnClickListener oclBtnButtonC
		buttonOk2.setOnClickListener(oclBtnButtonOk2);
		button1.setOnClickListener(oclBtnButton1);
		button2.setOnClickListener(oclBtnButton2);
		button3.setOnClickListener(oclBtnButton3);
		button4.setOnClickListener(oclBtnButton4);
		button5.setOnClickListener(oclBtnButton5);
		button6.setOnClickListener(oclBtnButton6);
		button7.setOnClickListener(oclBtnButton7);
		button8.setOnClickListener(oclBtnButton8);
		button9.setOnClickListener(oclBtnButton9);
		button0.setOnClickListener(oclBtnButton0);
		buttonC.setOnClickListener(oclBtnButtonC);
	}

}
